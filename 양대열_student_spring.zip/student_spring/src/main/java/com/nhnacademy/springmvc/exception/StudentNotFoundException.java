package com.nhnacademy.springmvc.exception;

public class StudentNotFoundException extends RuntimeException {

}
